"use strict";

console.log('console');