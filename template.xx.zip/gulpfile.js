const { src, dest, watch, series, parallel } = require('gulp');
const sass = require('gulp-sass');
const postcss = require('gulp-postcss');
const cssnano = require('cssnano');
const terser = require('gulp-terser');
const gcmq = require('gulp-group-css-media-queries');
const autoprefixer = require('autoprefixer');
const babel = require('gulp-babel');
const rename = require('gulp-rename');
const concat = require('gulp-concat');
const browsersync = require('browser-sync').create();

function taskScss() {
  return src('scss/*.scss', { sourcemaps: true })
    .pipe(sass({ outputStyle: 'expanded' }))
    .pipe(gcmq())
    .pipe(postcss([autoprefixer(), cssnano()]))
    .pipe(rename({ basename: 'app', suffix: '.min' }))
    .pipe(dest('css', { sourcemaps: '.' }));
};

function taskJS() {
  return src([
    //'js/jquery-1.12.4.min.js',
    'js/app.js'
  ], { sourcemaps: true })
    .pipe(concat('all.js'))
    .pipe(babel({ presets: ['@babel/preset-env'] }))
    .pipe(terser())
    .pipe(rename({ basename: 'app', suffix: '.min' }))
    .pipe(dest('js', { sourcemaps: '.' }));
};

function taskServer(cb) {
  browsersync.init({
    ui: false,
    notify: false,
    server: {
      baseDir: '.',
    },
    //proxy: 'domain.local'
  });
  cb();
};

function browsersyncReload(cb) {
  browsersync.reload();
  cb();
};

function taskWatch() {
  watch('*.html', browsersyncReload);
  watch('scss/**/*.scss', series(taskScss, browsersyncReload));
  watch('js/**/app.js', series(taskJS, browsersyncReload));
};

exports.taskScss = taskScss;
exports.taskJS = taskJS;
exports.taskServer = taskServer;
exports.taskWatch = taskWatch;

exports.build = parallel(taskScss, taskJS);
exports.default = series(taskScss, taskJS, taskServer, taskWatch);